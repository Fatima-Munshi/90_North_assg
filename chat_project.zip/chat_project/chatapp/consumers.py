from channels.generic.websocket import AsyncWebsocketConsumer
from django.contrib.auth.models import User
from .models import Message
import json
from asgiref.sync import sync_to_async

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.me = self.scope['user']
        self.other_username = self.scope['url_route']['kwargs']['username']
        self.other_user = await sync_to_async(User.objects.get)(username=self.other_username)
        self.room_name = f'chat_{min(self.me.username, self.other_username)}_{max(self.me.username, self.other_username)}'
        # Join room group
        await self.channel_layer.group_add(
            self.room_name,
            self.channel_name
        )
        await self.accept()

        messages = await self.get_messages()
        for message in messages:
            await self.send(text_data=json.dumps({
                'message': message.message,
                'sender': message.sender.username,       
            }))

    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.room_name,
            self.channel_name
        )

    # Receive message from WebSocket
    async def receive(self, text_data):
        data = json.loads(text_data)
        message = data['message']
        
        await self.save_message(message)
        # Send message to room group
        await self.channel_layer.group_send(
            self.room_name,
            {
                'type': 'chat_message',
                'message': message,
                'sender': self.me.username,
                
            }
        )

    # Receive message from room group
    async def chat_message(self, event):
        message = event['message'],
        sender = event['sender'],
        
        await self.send(text_data=json.dumps({
            'message': message,
            'sender': sender,
        }))

    @sync_to_async
    def save_message(self, message):
        Message.objects.create(
            sender=self.me, 
            recipient=self.other_user, 
            message=message
        )

    @sync_to_async
    def get_messages(self):
        return Message.objects.filter(
            sender__in=[self.me, self.other_user], 
            recipient__in=[self.me, self.other_user]
        ).order_by('timestamp')        